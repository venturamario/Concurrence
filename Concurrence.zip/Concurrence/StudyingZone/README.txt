#=======================================================================================================================
# PRACTICA 1 - PROGRAMACIÓN CONCURRENTE
# Mario Ventura & Luis Miguel Vargas
# Curso 2022 - 2023
# UIB - Grado en Ingeniería Informática - GIN3
#=======================================================================================================================

ENLACE AL VÍDEO EXPLICATIVO: https://youtu.be/qqHiw7C-flw

El algoritmo ha sido probado en numerosas ocasiones (ver simulación el vídeo) y ha funcionado correctamente
en todas ellas. Si sucede lo contrario, contactar con alguno de los autores del código.

OBSERVACIÓN: Debido a la semi aleatoriedad que presenta el programa, es posible que algunas de las impresiones
que se hacen por consola con el objetivo de facilitar el entendimiento de la simulación, se vean intercaladas.
A esto también contribuye la concurrencia en sí y los accesos de los procesos, ya que los prints no son operaciones
atómicas. Esto no quiere decir que el algoritmo no funcione.