//=======================================================================================================================
// 		PRACTICA 3 - PROGRAMACIÓN CONCURRENTE
// 		Mario Ventura & Luis Miguel Vargas
//		ARCHIVO: README
// 		Curso 2022 - 2023
// 		UIB - Grado en Ingeniería Informática - GIN3
//=======================================================================================================================

ENLACE AL VÍDEO ----> https://youtu.be/T002g3itw2I

El programa debería funcionar de forma correcta. Se ha probado en numerosas ocasiones y todas ellas con éxito.
En caso contrario, contactar con alguno de los autores